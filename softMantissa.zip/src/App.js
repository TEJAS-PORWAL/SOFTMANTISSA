import './App.css';
import Footer from './components/Footer';
import Services from './components/Services';
import HtmlContact from './components/HtmlContact';
import Navbar from './components/Navbar';
// import ServiceDetails from './components/ServiceDetails';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
function App() {
  return (
    <BrowserRouter>
    <section className="app">
    <Routes>
      {/* <Route exact path='/ServiceDetails' element= {  <>
                                                        <ServiceDetails/>
                                                        <Footer/>
                                                      </>
                                                    }
       /> */}
       {/* <Route exact path='/' element={Navbar} /> */}
       <Route exact path='/Contact' element={ <>
                                                <HtmlContact />
                                                <Footer/>
                                              </>
                                            } 
        />
       <Route exact path='/' element= { <>
                                                  <Services/>
                                                  <Footer/>
                                                </>
                                               } 
        />
       <Route exact path='/services' element= { <>
                                                  <Services/>
                                                  <Footer/>
                                                </>
                                               } 
        />
     </Routes>
    </section>
    </BrowserRouter>
  );
}

export default App;
