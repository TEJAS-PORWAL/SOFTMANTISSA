import React from 'react'
import './css/Contact.css';

export default function Contact() {
    return (
        <section className='contact-cont'>
            {/* <section className='contact-first'>
                <p>Get in Touch</p>
                <h2>Contact Us</h2>
            </section> */}
            <section className='contact-cards'>
                <div>
                    <div className='icon'>
                        <i className="fa fa-address-book-o" aria-hidden="true"></i>
                    </div>
                    <h2>Softmantisssa</h2>
                    <p>112, East West Cross, Magadi Main Rd, near Muthoo Finance, Bedarahalli, Bengaluru, Karnataka 560091</p>
                </div>
                <div>
                    <div className='icon'></div>
                    <h2>Bussiness Hours</h2>
                    <p>We are open 6 days a week from 10am to 6pm, Sunday closed</p>
                </div>
                <div>
                    <div className='icon'></div>
                    <h2>Let's Talk</h2>
                    <p>Phone Number: (+91)9513879960</p>
                </div>
            </section>
        </section>
    )
}
