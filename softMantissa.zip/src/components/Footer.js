import React, { useState } from "react";
import { Link } from "react-router-dom";
import '../components/css/Footer.css'
import logo from '../images/carbg.png'

function Footer() {

                // <-------BACKEND-------> 
    const [subs, setSubs] = useState(
        {
          Subscriber: ""
        }
      )
    
      let newSubs, newValue;
      const postSubs = (event) => {
        newSubs = event.target.name;
        newValue = event.target.value;
    
        setSubs({...subs, [newSubs]: newValue })
      }
                      // --------BACKEND------ 
            const Subscribed = async (event) =>{
              event.preventDefault()
              const {Subscriber} = subs
              if(Subscriber)
              {
                const response = await fetch(
                  "https://softmantissa-5178b-default-rtdb.firebaseio.com///SUBSCRIBER.json",
                  { method: "POST", headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({
                      Subscriber
                  }
                )
              }
            );
            if(response){
              setSubs({Subscriber: ""})
              alert("THANKS FOR SUBSCRIBING")
            }
            else {
              alert("PLEASE PROVIDE A VALID EMAIL")
            }
          }
          else {
            alert("PLEASE PROVIDE A VALID EMAIL")
          }
          }

  return (
    <>
   <footer className="footer-section">
        <div className="container">
            <div className="footer-cta pt-5 pb-5">
                <div className="row">
                    <div className="col-xl-4 col-md-4 mb-30">
                        <div className="single-cta">
                            <i className="fas fa-map-marker-alt"></i>
                            <div className="cta-text">
                                <h4>Find us</h4>
                                <span>4th cross Service Rd, Naagarabhaavi, 560072</span>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-4 col-md-4 mb-30">
                        <div className="single-cta">
                            <i className="fas fa-phone"></i>
                            <div className="cta-text">
                                <h4>Call us</h4>
                                <span>+91 9513879960</span>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-4 col-md-4 mb-30">
                        <div className="single-cta">
                            <i className="far fa-envelope-open"></i>
                            <div className="cta-text">
                                <h4>Mail us</h4>
                                <span>mail@info.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="footer-content pt-5 pb-5">
                <div className="row">
                    <div className="col-xl-4 col-lg-4 mb-50">
                        <div className="footer-widget">
                            <div className="footer-logo">
                                <img 
                                src={logo}
                                 className="img-fluid" alt="logo" />
                            </div>
                            <div className="footer-text">
                                <p>We create digital products. We specialize in designing interface,
                                     web experiences and meaningful products. See our work.
                                      Welcome to Softmantissa.
                                </p>
                            </div>
                            <div className="footer-social-icon">
                                <span>JOIN OUR COMMUNITY</span>
                                <a href="#"><i className="fab fa-facebook-f"></i></a>
                                <a href="#"><i className="fab fa-twitter"></i></a>
                                <a href="#"><i className="fab fa-google-plus-g"></i></a>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-4 col-lg-4 col-md-6 mb-30">
                        <div className="footer-widget">
                            <div className="footer-widget-heading">
                                <h3>Useful Links</h3>
                            </div>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Career</a></li>
                                <li><a href="#">Project</a></li>
                                <li><a href="#">Our Blogs</a></li>
                                <li><a href="#">Help Center</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Legal & Security</a></li>
                                <li><a href="#">Expert Team</a></li>
                                <li><Link to="/Contact">Contact us</Link></li>
                                <li><a href="#">Term of use</a></li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-xl-4 col-lg-4 col-md-6 mb-50">
                        <div className="footer-widget">
                            <div className="footer-widget-heading">
                                <h3>Subscribe</h3>
                            </div>
                            <div className="footer-text mb-25">
                                <p>Don't miss to subscribe to our new feeds, kindly fill the form below.</p>
                            </div>
                            <div className="subscribe-form">
                                <form action="#">
                                    <input type="email"
                                            name="Subscriber"
                                            value={subs.Subscriber}
                                            onChange={postSubs}
                                            placeholder="Your email address"
                                            autoComplete="off" />
                                    <button><i className="fab fa-telegram-plane"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="copyright-area">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6 col-lg-6 text-center text-lg-left">
                        <div className="copyright-text">
                            <p>Copyright &copy; 2022. All Right Reserved <a href="https://codepen.io/anupkumar92/">SOFTMANTISSA</a></p>
                        </div>
                    </div>
                    <div className="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                        <div className="footer-menu">
                            <ul>
                                <li><a href="#">Home</a></li>
                                <li><a href="#">Terms</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Policy</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    </>
  )
}

export default Footer