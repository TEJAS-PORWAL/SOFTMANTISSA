import React from 'react'
import '../components/css/Navbar.css'

function Navbar() {
  return (
    <>
        <navbar className="navbar navbar-expand-lg bg-dark navbar-dark shadow-sm px-5 py-3 py-lg-0">
        <a href="#" className="navbar-brand p-0">
            <h1 className="m-0 text-uppercase text-primary"
                style="color: white;font-size: 24px;font-family:Georgia, 'Times New Roman', Times, serif;"><span
                    style="color: blue;">S</span><span style="color: aliceblue;">oft</span><span
                    style="color: blue;">M</span><span style="color: aliceblue;">antissa</span></h1>
        </a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarCollapse">
            <div className="navbar-nav ms-auto py-0 me-n3">
                <a href="#" className="nav-item nav-link">Home</a>
                <a href="#" className="nav-item nav-link">About</a>
                <a href="#" className="nav-item nav-link active">Service</a>
                <a href="#" className="nav-item nav-link">Contact Us</a>
            </div>
        </div>
    </navbar>
    </>
  )
}

export default Navbar