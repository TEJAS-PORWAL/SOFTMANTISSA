import React from 'react'

function ServiceDetails() {
  return (
        <>
        
        {/* <section>
    <div className="container-fluid p-0" id="adjustment">
        <div id="header-carousel" className="carousel slide carousel-fade" data-bs-ride="carousel">
            <div className="carousel-inner">
                <div className="carousel-item active">
                    <img className="w-100" src="img/C1img.jpg" alt="Image" height="500px"/>
                    <div className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div className="p-3" style="max-width: 900px;">
                            <h1 className="text-white text-uppercase"
                                style="font-family: 'Poppins', sans-serif;font-size: 45px;">Our Services</h1>
                            <h5 className="display-1 text-white mb-md-4"
                                style="font-size: 20px;font-family:'Poppins', sans-serif;">We create experiences that
                                transform brands, grow businesses and make people’s lives better. Small teams working on
                                big challenges.</h5>
                        </div>
                    </div>
                </div>
                <div className="carousel-item">
                    <img className="w-100" src="img/C2img.jpg" alt="Image" height="500px"/>
                    <div className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div className="p-3" style="max-width: 900px;">
                            <h1 className="text-white text-uppercase"
                                style="font-family: 'Poppins', sans-serif;font-size: 45px;">Our Services</h1>
                            <h5 className="display-1 text-white mb-md-4"
                                style="font-size: 20px;font-family:'Poppins', sans-serif;">We create experiences that
                                transform brands, grow businesses and make people’s lives better. Small teams working on
                                big challenges.</h5>
                        </div>
                    </div>
                </div>
            </div>
            <button className="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Previous</span>
            </button>
            <button className="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    </section>    
    
<section>


  
    <div className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">Website Design</h1>
                <p>Web design is the creation of websites and pages to reflect a company’s brand and information and
                    ensure a user-friendly experience.Creating a web presence requires the right tools and an expert
                    team behind you. Get everything you
                    need to stand out from the competition. Our team will build a great looking website tailored to your
                    unique business goals. We make sure that your custom website reflects your brand and sets you up for
                    success online.

                </p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services1.jpg" style=" object-fit: cover;"/>
                </div>
            </div>
        </div>
    </div>
    
    <br/>
    <hr/>
   
    <div  className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">Digital Marketing</h1>
                <p>Digital marketing, also called online marketing, is the promotion of brands to connect with potential
                    customers using the internet and other forms of digital
                    communication.

                </p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services2.jpg" style="object-fit: cover;" />
                </div>
            </div>
        </div>
    </div> <br/>
    <hr/>
   
    <div className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">Apps development</h1>
                <p>Application development is the process of creating a computer program or a set of programs to perform
                    the different tasks that a business requires. <br/>Native Android app development<br/>
                    Native iOS app development<br/>
                    Web-based app development<br/>
                    Design Focused on Accessibility of all site content on all devices<br/>
                    Multiple-Device Testing<br/> </p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services3.jpg" style="object-fit: cover;"/>
                </div>
            </div>
        </div>
    </div> <br/>
    <hr/>
    
    <div className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">News portal & app</h1>
                <p>News Portal is an online communication medium for internet
                    users which are read all over the world. ... The news
                    portal development allows to publish publications, press
                    releases, columns, articles, blogs and other news related
                    content.
                </p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services4.jpg" style="object-fit: cover;"/>
                </div>
            </div>
        </div>
    </div> <br/>
    <hr/>
   
    <div className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">E-commerce websites & apps</h1>
                <p>E-commerce (electronic commerce) is the buying and selling of goods and services, or the transmitting
                    of funds or data, over an electronic network, primarily the internet.</p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services5.jpg" style="object-fit: cover;"/>
                </div>
            </div>
        </div>
    </div> <br/>
    <hr/>
   
    <div className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">Hospital Management System</h1>
                <p>A healthcare website is different from all other websites. It is a complex mix of services,
                    information, stories and applications. People visit a hospital website for plenty of reasons.
                    Hospitals are not like typical businesses; they are care givers and people who approach them are
                    usually in distress. Thus, it is crucial to create a balance between different components so that
                    they help achieve the goals of the healthcare website in an intuitive and strategic way.</p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services6.jpg" style="object-fit: cover;"/>
                </div>
            </div>
        </div>
    </div> <br/>
    <hr/>
   
    <div className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">Video Production</h1>
                <p>Video production is the process of producing video content for video. It is the equivalent of
                    filmmaking, but with video recorded either as analog signals on videotape, digitally in video tape
                    or as computer files stored on optical discs, hard drives, SSDs, magnetic tape or memory cards
                    instead of film stock.</p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services7.jpg" style="object-fit: cover;"/>
                </div>
            </div>
        </div>
    </div> <br/>
    <hr/>
   
    <div className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">Audio production & background</h1>
                <p>Let your voice be heard. Our skilled audio production department will help you capture the perfect
                    voice and sound to match your brand and bolster your campaigns.</p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services8.jpg" style="object-fit: cover;"/>
                </div>
            </div>
        </div>
    </div> <br/>
    <hr/>
    
    <div className="container-fluid bg-secondary px-0">
        <div className="row g-0">
            <div className="col-lg-6 py-6 px-5">
                <h1 className="display-5 mb-4">Graphic Desigining</h1>
                <p>Graphic design is a profession, academic discipline and applied art whose activity consists in
                    projecting visual communications intended to transmit specific messages to social groups, with
                    specific objectives.</p>
            </div>
            <div className="col-lg-6" style="min-height: 400px;">
                <div className="position-relative h-100">
                    <img className="position-absolute w-100 h-100" src="images\services9.jpg" style="object-fit: cover;"/>
                </div>
            </div>
        </div>
    </div> <br/>
    <hr/>   
    </section> */}

    
    {/* <a href='' target="_blank">hello</a> */}
</>
  )
}

export default ServiceDetails