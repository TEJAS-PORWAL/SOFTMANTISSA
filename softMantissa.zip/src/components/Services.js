import React from 'react'
import './css/Services.css'
import services_data from './Services.json';
// be the cards count be in the multiple of 3
// import { Link } from 'react-router-dom';

export default function Services() {

    
    return (
        <section className='services-cont'>
            <div className='services-first'>
                {/* <p>Our Services</p> */}
                <h2>You Dream it,<br /> we Make it True</h2>
            </div>
            <a href='https://aquamarine-gaufre-24bf6d.netlify.app' target="_blank" rel="noreferrer" style={{ textDecoration: "none" }}>
                <div className='cards-cont'>
                    {services_data.cards.map((card, index) => (
                        <div key={index} className="card">
                            <div></div>
                            <h3>{card[1]}</h3>
                        </div>
                    ))}
                </div>
            </a>
        </section>
    )
}
